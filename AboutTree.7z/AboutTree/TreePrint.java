package SummerMath.AboutTree;


import java.util.Stack;

public class TreePrint {
    //二叉树的遍历，分为前序遍历，中徐遍历和后序遍历,包括递归和非递归的方式
    //1,前序遍历
    public void PrePrint(TreeNode root){
        if(root == null){
            return;
        }
        System.out.println(root.value);
        PrePrint(root.left);
        PrePrint(root.right);
    }
    public void MidPrint(TreeNode root){
        if(root == null){
            return;
        }
        PrePrint(root.left);
        System.out.println(root.value);
        PrePrint(root.right);
    }
    public void PostPrint(TreeNode root){
        if(root == null){
            return;
        }
        PrePrint(root.left);
        PrePrint(root.right);
        System.out.println(root.value);
    }

    /**
     * 非递归的方式实现，主要是用到了栈
     * 每次来一个结点，放到栈里然后下一次取出来打印它在把它的左右结点放进去挨着取
     * @param root
     */
    public void NoDiguiPrePrint(TreeNode root){
        if(root == null){
            return;
        }
        TreeNode temp;
        Stack<TreeNode> stack = new Stack<>();
        stack.push(root);
        while(!stack.isEmpty()){
        temp = stack.pop();
        System.out.print(temp.value+" ");
        if(temp.left != null){
            stack.push(temp.left);
        }
        if(temp.right != null){
            stack.push(temp.right);
        }
    }
}

    /**
     * 从头结点开始入栈，往左走，遇到空了就打印，然后往右走，遇到空就出栈在往右走
     * @param root
     */
    public void NoDiguiMidPrint(TreeNode root){
        if(root == null){
            return;
        }
        TreeNode temp = root;
        Stack<TreeNode> stack = new Stack<>();
        while(!stack.isEmpty() || temp != null){
            if(temp != null){
                stack.push(temp);
                temp = temp.left;
            }else{
                temp = (TreeNode) stack.pop();
                System.out.print(temp.value+" ");
                temp = temp.right;
            }
        }
        System.out.println();
    }

    /**
     * 需要两个栈
     * 首先把头压到第一个栈里面去，然后拿出来放到第二个栈里面
     *然后如果头的两边不为空，先左后右放到第一个栈，如果为空就出栈
     * @param root
     */
    public void NoDiguiPrint(TreeNode root){
        if(root == null){
            return;
        }
        TreeNode temp = root;
        Stack<TreeNode> stack1 = new Stack<>();
        Stack<TreeNode> stack2 = new Stack<>();
        stack1.push(root);
        while(!stack1.isEmpty()){
            temp = stack1.pop();
            stack2.push(temp);
            if(temp.left != null){
                stack1.push(temp.left);
            }if(temp.right != null){
                stack1.push(temp.right);
            }
        }
        while(!stack2.isEmpty()){
            System.out.print(stack2.pop().value+" ");
        }
        System.out.println();
    }



}
class TreeNode{
    int value;
    public TreeNode left;
    public TreeNode right;
    public TreeNode parent; //指向自己的父结点，头结点指向null
    public TreeNode(int value){
        this.value = value;
    }
}
