package SummerMath.AboutTree;

import java.util.Stack;

public class IsSearchTree {
    /**
     * 判断一棵树是不是搜索二叉树，完全二叉树
     * 搜索二叉树：树上任何一个结点，左子树的结点都比他小，右子树都比他大,无重复值
     *完全二叉树：叶子结点都在最后两层，并且是从左到右都填满了的
     *思路一：递归 没想出来
     * 搜索二叉树：输入？没什么特别的要求，根节点就好
     * 返回值：boolean(左子树是否小于当前结点的值，右子树是否大于当前结点的值)结束条件？null
     *
     * 解法二：
     * 中序遍历 ，是依次升序的
     */

    public static boolean isSearchTree(TreeNode root){
     if(root == null){
         return false;
     }
     Stack<TreeNode> stack = new Stack<>();
     stack.push(root);
     int pre = stack.peek().value;
     TreeNode temp = root;
     while(!stack.isEmpty()){
         if(temp.left != null){
             stack.push(temp.left);
             temp = temp.left;
         }else{
             temp = stack.pop();
             if(temp.value < pre){
                 return false;
             }
             if(temp.right != null)
                stack.push(temp.right);
         }
         if(!stack.isEmpty()){
             pre = stack.peek().value;
         }

     }
        return  true;
    }
    // for test -- print tree
    public static void printTree(TreeNode head) {
        System.out.println("Binary Tree:");
        printInOrder(head, 0, "H", 17);
        System.out.println();
    }

    public static void printInOrder(TreeNode head, int height, String to, int len) {
        if (head == null) {
            return;
        }
        printInOrder(head.right, height + 1, "v", len);
        String val = to + head.value + to;
        int lenM = val.length();
        int lenL = (len - lenM) / 2;
        int lenR = len - lenM - lenL;
        val = getSpace(lenL) + val + getSpace(lenR);
        System.out.println(getSpace(height * len) + val);
        printInOrder(head.left, height + 1, "^", len);
    }

    public static String getSpace(int num) {
        String space = " ";
        StringBuffer buf = new StringBuffer("");
        for (int i = 0; i < num; i++) {
            buf.append(space);
        }
        return buf.toString();
    }

    public static void main(String[] args) {
        TreeNode head = new TreeNode(4);
        head.left = new TreeNode(2);
        head.right = new TreeNode(6);
        head.left.left = new TreeNode(1);
        head.left.right = new TreeNode(3);
        head.right.left = new TreeNode(5);

        printTree(head);
        System.out.println(isSearchTree(head));
        System.out.println(isSearchTree(head));

    }

}
