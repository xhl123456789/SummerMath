package SummerMath.AboutTree;

import java.util.LinkedList;
import java.util.Queue;

public class SerializeTree {
    /**
     * 所谓二叉树的序列化与反序列化：就是将数据变成文件永久的保存起来，或者将文件变成数据
     * 将二叉树遍历，在每个数据后面加标识符，然后以字符串的方式返回
     */
    public static String PreSerilizeTree(TreeNode root){
        if(root == null){
            return "#";
        }
        return root.value+"_"+PreSerilizeTree(root.left)+PreSerilizeTree(root.right);
    }
    //反序列化
    public TreeNode ReconSerilizeTree(String s){
        if(s.equals("") && s == null){
            return null;
        }
        String[] values = s.split("_#");
        Queue<String> queue = new LinkedList<String>();//把数组放进队列，取的时候方便
        for(int i=0;i<values.length;i++){
            queue.offer(values[i]);
        }

        return null;
    }
    public static TreeNode reconPreOrder(Queue<String> queue) {
        String value = queue.poll();
        if (value.equals("#")) {
            return null;
        }
        TreeNode head = new TreeNode(Integer.valueOf(value));
        head.left = reconPreOrder(queue);
        head.right = reconPreOrder(queue);
        return head;
    }


    public static void printTree(TreeNode head) {
        System.out.println("Binary Tree:");
        printInOrder(head, 0, "H", 17);
        System.out.println();
    }
    public static void printInOrder(TreeNode head, int height, String to, int len) {
        if (head == null) {
            return;
        }
        printInOrder(head.right, height + 1, "v", len);
        String val = to + head.value + to;
        int lenM = val.length();
        int lenL = (len - lenM) / 2;
        int lenR = len - lenM - lenL;
        val = getSpace(lenL) + val + getSpace(lenR);
        System.out.println(getSpace(height * len) + val);
        printInOrder(head.left, height + 1, "^", len);
    }
    public static String getSpace(int num) {
        String space = " ";
        StringBuffer buf = new StringBuffer("");
        for (int i = 0; i < num; i++) {
            buf.append(space);
        }
        return buf.toString();
    }
    public static void main(String[] args) {
        TreeNode head = new TreeNode(100);
        head.left = new TreeNode(21);
        head.left.left = new TreeNode(37);
        head.right = new TreeNode(-42);
        head.right.left = new TreeNode(0);
        head.right.right = new TreeNode(666);
        printTree(head);
        System.out.println(PreSerilizeTree(head));
    }
}
