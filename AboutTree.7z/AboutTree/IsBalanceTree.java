package SummerMath.AboutTree;

public class IsBalanceTree {
    /**
     * 判断一棵树是否是平衡二叉树：
     * 所谓平衡二叉树就是：一颗树的任何一个结点左子树和右子树的高度都不超过一
     * 用递归的方式；
     * 思考题要从这么几个方面去想，我应该输入什么，我的返回值应该是什么。
     * 我们判断一棵树是否是平衡二叉树，来到一个结点我们首先判断右子树是否平衡，然后看左子树是否平衡
     * 然后来到当前结点，拿到左右子树的高度，看看它们的高度差是否超过了一
     * 那么我们就要考虑，输入返回，输入没有特别的要求，主要就是根节点
     * 返回需要看是否平衡，然后收集树得高度
     */
    //首先定义一个返回值类型
    public static class ReturnType{
        public boolean isBalance;
        public int high;

        public ReturnType(Boolean isBalance,int h){
            this.isBalance = isBalance;
            this.high = h;
        }
    }
    //然后就是逻辑思路
    public static ReturnType process(TreeNode head){
        if(head == null){
            return new ReturnType(true,0);
        }
        //判断左子树是否平衡
        ReturnType Lres = process(head.left);
        if(!Lres.isBalance){ //不平衡直接返回
            return new ReturnType(false,0);
        }
        ReturnType Rres = process(head.right);
        if(!Rres.isBalance){
            return new ReturnType(false,0);
        }
        if(Math.abs(Lres.high-Rres.high)>1){
            return  new ReturnType(false,0);
        }
        return new ReturnType(true,Math.max(Lres.high,Rres.high)+1);  //返回得高度
    }
    public static boolean isBalance(TreeNode head){
        return process(head).isBalance;
    }

}
