package SummerMath.AboutTree;

import sun.reflect.generics.tree.Tree;

import java.util.Stack;

public class NextTreeNode {
    //查找树的某一个结点的后继结点 就是按照中继遍历，给定某一结点，然后查找它的后继结点
    //（1）比较传统的方法，中序遍历，然后找到那个结点的下一个结点，但是只给了一个结点，要找到头结点，有无parent指针域？有
    //(2)分两种情况。一是如果该结点有右子树，那么它的后继结点肯定是右子树最左的结点
    //             如果没有右子树，那么就找哪一个结点的左子树是以该结点结尾的？两个指针，一个是父亲一个是孩子，同时往上，如果孩子是
    //             父亲的左孩子就找到了
    public TreeNode findNextNode(TreeNode node){
        boolean flag = false;
        if(node == null){
            return null;
        }
        TreeNode root = null;
        while(node.parent != null){
            root = node.parent;
        }
        TreePrint p = new TreePrint();
        TreeNode temp = root;
        Stack<TreeNode> stack = new Stack<>();
        while(!stack.isEmpty() || temp != null){
            if(temp != null){
                stack.push(temp);
                temp = temp.left;
            }else{
                temp = (TreeNode) stack.pop();
                if(temp == node){
                   flag = true;
                }
                if(flag = true){
                    return temp;
                }
                temp = temp.right;
            }
        }
        return null;
    }

    /**
     * 分两种情况 1是有右子树 2是没右子树
     * @param node
     * @return
     */
    public TreeNode findNextNode2(TreeNode node){
        if(node == null){
            return null;
        }
        if(node.right == null){  //无右子树,就找哪一个结点左子树是以该结点结尾的
            //怎么找？两个指针往上走
            TreeNode parent = node.parent;
            TreeNode child = node;
            while(parent.left != child && parent != null){
                child = parent;
                parent = parent.parent;
            }
            return parent;
        }else{  //右子树不为空，找到它右子树的最左的结点
            TreeNode tem = node.right;
            while(tem.left != null){
                tem = tem.left;
            }
            return tem;
        }
    }
}
