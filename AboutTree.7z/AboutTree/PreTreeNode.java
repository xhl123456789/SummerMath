package SummerMath.AboutTree;

public class PreTreeNode {
    /**
     * 分两种情况。一是该节点有左子树，就是左子树最右的结点
     * 二是没有左子树：往上找，孩子是父亲的右子节点，父节点是他孩子的右节点就停
     */
    public TreeNode findPreNode(TreeNode node){
        if(node == null){
            return null;
        }
        if(node.left != null){ //如果该节点有左子节点，那么前驱就是左树的最右的·结点
            TreeNode temp = node.left;
            while(temp.right!=null){
                temp = temp.right;
            }
            return temp;
        } else {   //没有左子节点, 是哪一个结点的最右子节点 两个指针
            TreeNode parent = node.parent;
            TreeNode child = node;
            while(child != parent.right && parent != null){
                child = parent;
                parent = parent.parent;
            }
            return parent;
        }
    }
}
