package SummerMath.AboutTree;

import java.util.LinkedList;
import java.util.Queue;

public class IsCompleteTree {
    /**
     * 判断一棵树是否是完全二叉树
     * 如果某一个结点只有右子节点没有左子结点  比较好判断
     * 所有叶子结点遍布在最后两层   怎么判断？
     *
     * 思路就是按层遍历,主要分两种情况
     * 情况一：如果某个结点只有右子树没有左子树那就不是了。
     * 情况二：如果某个结点只有左子树，没有右子树，那么后面遇到的所有结点都是叶子结点，
     *         还有就是遇到的左右都没有结点，那么后面遇到的所有也都是叶子结点
     */

    public boolean isCompleteTree(TreeNode root){
        if(root == null){
            return false;
        }
        Boolean flag = false;  //是否开启情况二
        Queue<TreeNode> queue = new LinkedList<>();
        queue.offer(root);    //入队
        TreeNode Left;
        TreeNode Right;
        while(!queue.isEmpty()){
            root = queue.poll();
            Left = root.left;
            Right = root.right;
            if((flag && Left!=null && Right != null) || (Left == null||Right != null)){
                return false;
            }
            if(Left != null){
                queue.offer(Left);
            }
            if(Right != null){
                queue.offer(Right);
            }else {
                flag = true;
            }
        }
        return true;
    }
}
