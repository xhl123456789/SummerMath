package SummerMath.AboutTree;

public class CompletelyTreeNum {
    /**
     * 一颗完全二叉树，求它结点的个数
     * 首先根据左子结点求得树的的高度L
     * 1，然后判断左子树是否满的，如果满的那么左子树的结点个数就为左子树的高度2^l-1加根节点1，
     * 然后同理右子树求，右子树肯定也是一颗满二叉树
     * 2，如果左子树不满，那么右子树的是一颗满二叉树可以2^l
     * 左子树又是完全二叉树
     */
    public int ComTreeNodeNum(TreeNode root){
        if(root == null){
            return 0;
        }
        return bs(root,getLevel(root,1),1);  //需要的参数根节点，当前结点在第几层，以及高度
    }
    public int bs(TreeNode node ,int high,int level){
        if(level == high){  //注意这里的结束条件，是 层数和高度相等了之后就说明来到了叶子结点，就返回一个
            return 1;
        }
        if(getLevel(node.right,level+1) == high){ //说明左子树是满树  那么左边的数的结点个数就是2的H-L次方，在递归求右边的结点个数
            return (1<<(high-level))+bs(node.right,high,level+1);
        }else { //否则右边的就是一个满二叉树，高度比总的高度少一，左边的完全二叉树递归
            return (1<<(high-level-1))+bs(node.left,high,level+1);
        }
    }
    public int getLevel(TreeNode node,int L){  //获取完全二叉树的高度
        if(node == null){
            return 0;
        }
        int level = 0;
        while(node.left != null){
            node = node.left;
            level++;
        }
        return level - L;
    }
}
