package SummerMath.AboutTree;

public class PaperFolding {
    /**
     * 请把一段纸条竖着放在桌子上，然后从纸条的下边向上方对折1次，压出折痕后展开。
     *
     * 此时 折痕是凹下去的，即折痕突起的方向指向纸条的背面。如果从纸条的下边向上方连续对折
     *
     * 2 次，压出折痕后展开，此时有三条折痕，从上到下依次是下折痕、下折痕和上折痕。
     *
     * 给定一 个输入参数N，代表纸条都从下边向上方连续对折N次，请从上到下打印所有折痕的方向。
     *
     * 例如：N=1时，打印： down；N=2时，打印： down down up
     * 通过总结规律的当折了n次时，折痕顺序是是n层的二叉树中序遍历顺序
     * 树是这样的：跟结点开始每个结点的左结点是下，右节点是上，对应n次就对应n层的中序遍历
     *       下
     *   下      上
     * 下  上  下   上
     * 比如说
     */
    public static void printAllFolds(int N) {
        printProcess(1, N, true);
    }

    public static void printProcess(int i, int N, boolean down) {
        if (i > N) {//4
            return;
        }
        printProcess(i + 1, N, true);
        System.out.println(down ? "down " : "up ");
        printProcess(i + 1, N, false);
    }

    public static void main(String[] args) {
        int N = 4;
        printAllFolds(N);
    }

}
